const express =  require('express');

const app = express();
const router = express.Router();

const index = require('./routes/index');
const userRouter = require('./routes/userRoute');

module.exports = app;